# Coursera-Front-End-Web-UI-Frameworks-Bootstrap
Repository for Coursera Front-End Web UI Frameworks and Tools - Bootstrap (assignments 1, 2, 3 and 4)

Course overview:


Week 1 - Front-end Web UI Frameworks Overview: Bootstrap

Full Stack Web Development: The Big Picture.
Introduction to Bootstrap.
Responsive Design and Bootstrap Grid System.
Navigation and Navigation Bar.
Assignment 1.

Week 2 - Bootstrap CSS Components

User Input: Buttons and Forms.
Displaying Content: Tables, Panels, Wells.
Images and Media: Images, Thumbnails, Media Objects.
Alerting Users: Labels, Badges, Alerts, Progress Bars.
Assignment 2.

Week 3 - Bootstrap Javascript Components

Bootstrap JavaScript Components Overview.
Tabs, Pills and Tabbed Navigation.
Hide and Seek: Collapse, Accordion, Scrollspy and Affix.
Revealing Content: Tooltips, Popovers and Modals.
Carousel.
Assignment 3.

Week 4 - Web Tools

Bootstrap and JQuery.
Node.js and Node Package Manager.
Less is More!: Less and Sass.
Web Tools: Bower.
Assignment 4.
